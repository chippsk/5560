'use strict';

/* Controllers */

angular.module('myApp.controllers', [])
        .controller('MyCtrl1', ['$scope', function($scope) {
                $scope.add = function() {
                    $scope.num3 = $scope.num1 + $scope.num2;
                };
            }])
        .controller('MyCtrl2', ['$scope', function($scope) {
                $scope.cars = [
                    {make: "Ford", year: 2004},
                    {make: "BMW", year: 2002},
                    {make: "Infiniti", year: 2006},
                    {make: "Lexus", year: 2008},
                ];
                $scope.addCar = function() {
                    $scope.cars.push({make: $scope.make, year: $scope.year});
                };
                $scope.removeCar = function() {
                    var index1 =0;
                    while(index1<$scope.cars.length){
                        if($scope.cars[index1].make == $scope.make){
                            $scope.cars.splice(index1, 1);
                        }
                        index1++;
                    }
                };
            }]);
